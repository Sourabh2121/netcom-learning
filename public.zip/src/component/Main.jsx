import React from "react";

const Main = () => {
  return (
    <>
      <div className="h-calc w-full">
        <div className="bg-[#099A83] px-4 md:px-[50px]  text-left">
          <p className="text-xs text-white pt-[22px] font-medium">
            Completed class / DP-100T01: Designing and Implementing a Data
            Science Solution on Azure (Data Scientist)
          </p>
          <div className="flex gap-2 pt-8">
            <div className="border text-[11px] border-[#23E6ED] text-[#181A53] font-medium px-1 mx-1 my-0.5 h-[18px] flex items-center justify-center bg-[#C4FDFF] rounded-[4px]">
              Microsoft
            </div>
            <div className="border text-[11px] border-[#FFD9B5] text-[#181A53] font-medium px-1 mx-1 my-0.5 h-[18px] flex items-center justify-center bg-[#FFD9B5] rounded-[4px]">
              Public class
            </div>
          </div>
          <h2 className="text-[24px] pt-[18px] text-white">
            DP-100T01: Designing and Implementing a Data Science Solution on{" "}
            <br />
            Azure(Data Scientist)
          </h2>
          <div className="flex gap-[19px] pt-4">
            <span className="text-[16px] text-white font-medium">
              Completed On : 24 Feb, 2023
            </span>
            <span className="text-[16px] text-white flex items-center gap-2">
              <img src="richard.png" alt="richard" className="" />{" "}
              <span className="font-medium">Richard B</span>
            </span>
          </div>
          <div className="flex gap-2 items-center pt-[33px]">
            <img src="attendance.png" className="pr-2" alt="attendance" />
            <p className="text-sm text-[#71FF9D] font-semibold">
              Your Attendance:100%
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 items-center gap-[16px] pt-9 pb-[120px]">
            <div className="py-2 px-4 bg-[#0876F8] rounded-lg text-white text-sm font-semibold">
              Last Day Evaluation
            </div>
            <div className="py-2 px-4 border border-[#FFFFFF66] rounded-lg text-white text-sm font-semibold">
              Buy Exam
            </div>
            <div className="py-2 px-4 border border-[#FFFFFF66] rounded-lg text-white text-sm font-semibold">
              Access Digital Assets
            </div>
            <div className="py-2 px-4 border border-[#FFFFFF66] rounded-lg text-white text-sm font-semibold">
              Class Recordings
            </div>
            <div className="py-2 px-4 border border-[#FFFFFF66] rounded-lg text-white text-sm font-semibold">
              Additional Resources
            </div>
          </div>
        </div>
        <div className="md:px-[50px] px-4 flex flex-col md:flex-row gap-4 mb-8 -mt-20">
          <div className="shadow-card flex items-center justify-between rounded-[12px] text-left bg-white px-7 py-[24px] w-full md:w-1/2">
            <div>
              <h5 className="text-[#181A53] text-[20px] font-semibold mb-2">
                Claim your Badge
              </h5>
              <p className="text-sm text-[#181A53] mb-[16px]">
                Scan QR to download on Mobile Phone
              </p>
              <div className="bg-[#0876F8] inline-block text-xs text-white  rounded-[7px] px-3 py-[9px]">
                Download
              </div>
            </div>
            <div className="">
              <img src="qr.png" alt="ar" className="" />
            </div>
          </div>
          <div className="shadow-card flex items-center justify-between rounded-[12px] text-left bg-white px-7 py-[24px] w-full md:w-1/2">
            <div>
              <h5 className="text-[#181A53] text-[20px] font-semibold mb-2">
                Download Certificate
              </h5>
              <p className="text-sm text-[#181A53] mb-[16px]">
                Download your certificate or share it to your social.
              </p>
              <div className="flex gap-2 items-center">
                <div className="bg-[#0876F8] text-xs inline-block text-white  rounded-[7px] px-3 py-[9px]">
                  Download
                </div>
                <img src="share.png" alt="share" />
              </div>
            </div>
            <div className="">
              <img src="certificate.png" alt="certificate" className="" />
            </div>
          </div>
        </div>
        <div className="md:px-[50px] px-4 mb-10">
          <div className="py-4 px-5 shadow-card text-left bg-white rounded-[12px] flex flex-col md:flex-row md:items-center">
            <div className="pr-[61px] md:pl-[40px] mb-4 md:mb-0">
              Access <br className="hidden md:inline-block" /> lab module
            </div>
            <div className="bg-[#E2E2E2] rounded-lg px-6 py-[18px] w-full">
              <p className="text-[#181A53] text-sm font-semibold mb-3">
                Lab module
              </p>
              <div className="flex flex-col md:flex-row items-center gap-5">
                <div className="h-9 text-[#181A53] bg-white text-xs rounded-lg w-full pl-4 flex items-center border border-[#E2E2E2]">
                  01 Exploring the Lab Environment
                </div>
                <div className="bg-[#0876F8] px-7 py-2 inline-block text-white text-sm font-semibold  rounded-[8px]">
                  Access LAB
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex px-[50px] gap-[19px]">
          <div className="border border-[#E2E2E2] rounded-xl shadow-card bg-white h-full px-10 pt-[18px]">
            <ul className="flex items-center gap-[27.4px] border-b-2 border-[#E2E2E2]">
              <li className="text-[16px] font-semibold pb-[14px] border-b-4 border-[#0876F8] text-[#0876F8]">
                Day 1
              </li>
              <li className="text-[16px] font-semibold pb-[14px]">Day 2</li>
              <li className="text-[16px] font-semibold pb-[14px]">Day 3</li>
            </ul>
          </div>
          <div></div>
        </div>
      </div>
    </>
  );
};

export default Main;
