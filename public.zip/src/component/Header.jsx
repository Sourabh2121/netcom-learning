import React from "react";

const Header = () => {
  return (
    <>
      <div className="h-16 w-full justify-between flex items-center bg-white px-5">
        <div className="flex items-center">
          <img src="netcom-logo.png" alt="logo" className="" />
          <div className="pl-4 lg:pl-28">
            <div className="relative">
              <input
                type="search"
                className="border rounded-lg h-9 pl-11 input-search w-1/3"
                placeholder="search"
              />
              <img
                src="search.png"
                alt="search"
                className="absolute left-2.5 top-1/2 -translate-y-1/2"
              />
            </div>
          </div>
        </div>
        <ul className="navbar-icons flex items-center">
          <li>
            <img src="notification.png" alt="notification" />
          </li>
          <li>
            <img src="cart.png" alt="cart" />
          </li>
          <li className="flex items-center !pr-0">
            <span className="w-9 h-9 rounded-full">
              <img src="profile.png" alt="profile" className="object-fit" />
            </span>
            <span className="text-sm text-[##181A53] pl-2.5">R. Spencer</span>
            <span className="w-6 h-6 flex items-center justify-center bg-[#E2E2E2] rounded-lg ml-3"></span>
          </li>
        </ul>
      </div>
    </>
  );
};

export default Header;
