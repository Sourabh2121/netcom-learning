import React, { useState } from "react";

const SideBar = () => {
  const [sideBar, setSideBar] = useState(false);

  const openMenu = () => {
    setSideBar(true);
  };

  const closeMenu = () => {
    setSideBar(false);
  };

  return (
    <>
      <div className="md:hidden absolute top-0 left-4 h-10 w-36">
              <span onClick={openMenu} className="cursor-pointerbg-transparent opacity-10">
                  -
        </span>
      </div>

      <div
        className={`fixed md:relative inset-0 transition-transform duration-300 bg-white shadow-lg ${
          sideBar ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0 md:block`}
      >
        <div className="min-w-[244px] h-full">
          <div className="flex justify-between items-center p-4">
            <span className="text-xl font-semibold">Menu</span>
            {/* Close button for mobile view */}
            <button onClick={closeMenu} className="text-[#181A53] md:hidden">
              <img src="close-icon.png" alt="Close" className="h-6" />
            </button>
          </div>

          {/* Sidebar menu items */}
          <ul className="px-5 py-4">
            <li className="flex items-center gap-2.5 my-0.5 py-2.5 pl-3">
              <img src="dashboard.png" alt="Dashboard" />
              <span className="text-[#181A53]">Dashboard</span>
            </li>
            <li className="flex items-center gap-2.5 my-0.5 py-2.5 bg-[#0876F8] text-white pl-3 rounded-lg">
              <img src="training-classes.png" alt="Training classes" />
              <span className="text-[#fff]">Training classes</span>
            </li>
            <li className="flex items-center gap-2.5 my-0.5 py-2.5 pl-3 rounded-lg">
              <img src="e-learning.png" alt="e-Learning" />
              <span className="text-[#181A53]">e-Learning</span>
            </li>
            <li className="flex items-center gap-2.5 my-0.5 py-2.5 pl-3 rounded-lg">
              <img src="course-catalog.png" alt="Course Catalog" />
              <span className="text-[#181A53]">Course Catalog</span>
            </li>
            <li className="flex items-center gap-2.5 my-0.5 py-2.5 pl-3 rounded-lg">
              <img src="resources.png" alt="Resources" />
              <span className="text-[#181A53]">Resources</span>
            </li>
            <li className="flex items-center gap-2.5 my-0.5 py-2.5 pl-3 rounded-lg">
              <img src="training-calendar.png" alt="Training calendar" />
              <span className="text-[#181A53]">Training calendar</span>
            </li>
          </ul>
          <hr className="pb-6 mt-6" />
          <ul className="px-5">
            <li className="flex items-center gap-2.5 my-0.5 py-2 pl-3 rounded-lg">
              <img src="help-center.png" alt="Help center" />
              <span className="text-[#181A53]">Help center</span>
            </li>
            <li className="flex items-center gap-2.5 my-0.5 py-2 pl-3 rounded-lg">
              <img src="settings.png" alt="Settings" />
              <span className="text-[#181A53]">Settings</span>
            </li>
          </ul>
          <ul className="px-5 py-7">
            <li className="flex items-center gap-2.5 my-0.5 py-2 pl-3 rounded-lg">
              <img src="training-classes.png" alt="Training classes" />
              <span className="text-[#181A53]">Training classes</span>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default SideBar;
